
import React from "react";

export default function SafarClub() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <header className="text-center py-10 border-b border-gray-800">
        <h1 className="text-4xl font-bold">SafarClub</h1>
        <p className="mt-2 text-gray-400">From Small Towns to Thailand — Powered by AI</p>
      </header>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">How It Works</h2>
        <ol className="list-decimal ml-6 text-gray-300">
          <li>Choose a subscription plan (₹99, ₹199, ₹399)</li>
          <li>Tell us your dream trip (Thailand, Goa, Dubai...)</li>
          <li>Our AI curates your trip based on your budget</li>
          <li>Book and go — everything is simplified</li>
        </ol>
      </section>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">Sample Trips</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="bg-gray-900 p-4 rounded-xl">
            <h3 className="text-xl font-bold">Goa – ₹1,999</h3>
            <p className="text-sm text-gray-400">2N/3D stay + travel + guide</p>
          </div>
          <div className="bg-gray-900 p-4 rounded-xl">
            <h3 className="text-xl font-bold">Thailand – ₹29,000</h3>
            <p className="text-sm text-gray-400">Flights + 4 nights + island tour</p>
          </div>
          <div className="bg-gray-900 p-4 rounded-xl">
            <h3 className="text-xl font-bold">Dubai – ₹35,000</h3>
            <p className="text-sm text-gray-400">Visa + Flights + Desert Safari</p>
          </div>
        </div>
      </section>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">Subscription Plans</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="bg-gray-800 p-4 rounded-xl border border-gray-600">
            <h3 className="text-lg font-bold">Basic – ₹99/mo</h3>
            <p className="text-sm text-gray-400">Domestic trips only</p>
          </div>
          <div className="bg-gray-800 p-4 rounded-xl border border-gray-600">
            <h3 className="text-lg font-bold">Plus – ₹199/mo</h3>
            <p className="text-sm text-gray-400">Includes Thailand, Bali</p>
          </div>
          <div className="bg-gray-800 p-4 rounded-xl border border-gray-600">
            <h3 className="text-lg font-bold">Elite – ₹399/mo</h3>
            <p className="text-sm text-gray-400">Full access + priority trips</p>
          </div>
        </div>
      </section>

      <section className="p-6 max-w-4xl mx-auto text-center">
        <h2 className="text-2xl font-semibold mb-2">Join the Waitlist</h2>
        <p className="text-gray-400 mb-4">We’re launching soon. Be the first to travel smart.</p>
        <input className="px-4 py-2 text-black rounded" placeholder="Enter your email" />
        <button className="ml-2 px-4 py-2 bg-green-500 rounded hover:bg-green-600">Notify Me</button>
      </section>

      <footer className="text-center py-6 border-t border-gray-800 text-gray-500 text-sm">
        © 2025 SafarClub. Made in India with heart.
      </footer>
    </div>
  );
}
